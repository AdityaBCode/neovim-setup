return {
  -- Color Scheme
  { "ellisonleao/gruvbox.nvim" }, -- Gruvbox theme

  -- LSP and Completion
  { "neovim/nvim-lspconfig" }, -- LSP configurations
  { "williamboman/mason.nvim" }, -- LSP manager
  { "L3MON4D3/LuaSnip" }, -- Snippet engine
  { "rafamadriz/friendly-snippets" }, -- Predefined snippets

  -- Web Development Plugins
  { "mattn/emmet-vim" }, -- Emmet for HTML & CSS
  { "ap/vim-css-color" }, -- CSS color preview
  { "maxmellon/vim-jsx-pretty" }, -- JSX syntax highlighting
  { "pangloss/vim-javascript" }, -- JavaScript syntax support
  { "windwp/nvim-ts-autotag" }, -- Auto close and rename HTML tags

  -- Git Integration
  { "tpope/vim-fugitive" }, -- Git commands inside Neovim
  { "lewis6991/gitsigns.nvim" }, -- Show git changes in the gutter

  -- Formatting & Linting
  { "prettier/vim-prettier", run = "yarn install --frozen-lockfile --production" }, -- Prettier for formatting
  { "mhartington/formatter.nvim" }, -- Code formatter

  -- UI Enhancements
  { "glepnir/dashboard-nvim" }, -- Dashboard for Neovim
  { "akinsho/nvim-bufferline.lua" }, -- Better buffer management
  { "nvim-lualine/lualine.nvim" }, -- Status line
  { "folke/which-key.nvim" }, -- Keybinding helper

  -- Utilities
  { "windwp/nvim-autopairs" }, -- Auto close brackets and quotes
  { "norcalli/nvim-colorizer.lua" }, -- Color preview for CSS and other files
  { "nvim-treesitter/nvim-treesitter", run = ":TSUpdate" }, -- Better syntax highlighting



  -- Python Development Plugins
  { "williamboman/mason-lspconfig.nvim" }, -- Mason LSP config
  { "python-lsp/python-lsp-server" }, -- Python LSP server
  { "mfussenegger/nvim-dap-python" }, -- Debug Adapter Protocol for Python
  { "nvim-treesitter/nvim-treesitter", run = ":TSUpdate" }, -- Better syntax highlighting (already present)
  { "psf/black" }, -- Python code formatter
  { "Vimjas/vim-python-pep8-indent" }, -- Python-specific indentation

  -- Add mini.ai plugin
  {
    "echasnovski/mini.ai",
    event = "VeryLazy",
    opts = function()
    local ai = require("mini.ai")
    return {
      n_lines = 500,
      custom_textobjects = {
        o = ai.gen_spec.treesitter({ -- code block
          a = { "@block.outer", "@conditional.outer", "@loop.outer" },
          i = { "@block.inner", "@conditional.inner", "@loop.inner" },
        }),
        f = ai.gen_spec.treesitter({ a = "@function.outer", i = "@function.inner" }), -- function
        c = ai.gen_spec.treesitter({ a = "@class.outer", i = "@class.inner" }), -- class
        t = { "<([%p%w]-)%f[^<%w][^<>]->.-</%1>", "^<.->().*()</[^/]->$" }, -- tags
        d = { "%f[%d]%d+" }, -- digits
        e = { -- Word with case
          { "%u[%l%d]+%f[^%l%d]", "%f[%S][%l%d]+%f[^%l%d]", "%f[%P][%l%d]+%f[^%l%d]", "^[%l%d]+%f[^%l%d]" },
          "^().*()$",
        },
        g = LazyVim.mini.ai_buffer, -- buffer
        u = ai.gen_spec.function_call(), -- u for "Usage"
        U = ai.gen_spec.function_call({ name_pattern = "[%w_]" }), -- without dot in function name
      },
    }
    end,
    config = function(_, opts)
    require("mini.ai").setup(opts)
    LazyVim.on_load("which-key.nvim", function()
    vim.schedule(function()
    LazyVim.mini.ai_whichkey(opts)
    end)
    end)
    end,
  }


}
